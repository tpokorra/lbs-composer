<?php

namespace DirDotPhp;

class Dir {}

