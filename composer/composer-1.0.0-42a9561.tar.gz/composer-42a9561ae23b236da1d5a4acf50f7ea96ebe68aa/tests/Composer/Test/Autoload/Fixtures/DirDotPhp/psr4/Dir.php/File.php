<?php

namespace DirDotPhp\Dir.php;

class File {}

