<?php

namespace Foo\Bar;

class A {}
class B {}
